import React, {useState} from 'react';
import {Typography, Container, makeStyles} from "@material-ui/core";
import RepositoryList from "./RepositoryList";
import SearchBar from "./SearchBar";
import { ApolloProvider } from '@apollo/react-hooks';
import client from './Client';
import ReactLoginMS from "react-ms-login";

import GitHubLogin from 'react-github-login';
import Main from './Routes';
import Login from './Login';
import { BrowserRouter as Router } from 'react-router-dom';
const useStyles = makeStyles({
  title: {
    marginTop: '1rem',
    marginBottom: '1rem',
    textAlign: 'center',
    backgroundColor: 'grey'
  },
  body: {
    // marginTop: '1rem',
    // marginBottom: '1rem',
    // textAlign: 'center',

    width:"50%",
    marginLeft: "auto",
    marginRight: "auto"
 
  },
  main: {
    // backgroundColor: '#A9A9A9',
    // height:"100%",
    // marginBottom:"0px"
  }
});

const App = () => {
  const classes = useStyles();
  const [searchTerm, setSearchTerm] = useState('');
  const onSuccessGithub = (response) => {
    console.log(response.code);
  } 

  return (
    <Router> 
    <Login/>
    
  </Router>

    // <div className="App" align="center">
    //     <h1>LOGIN WITH GITHUB </h1>

    //       {/*CLIENTID REDIRECTURI NOT CREATED YET*/}

    //       <GitHubLogin clientId="1b3bd479b7f7383766f0"
    //         onSuccess={onSuccessGithub}
    //         buttonText="LOGIN WITH GITHUB"
    //         className="git-login"
    //         valid={true}
    //         redirectUri="http://localhost:3000"
    //       />
    
    // {/* // <Container maxWidth={'xl'}  className={classes.main} >
    // <ApolloProvider client={client}>
 
    //   <div className={classes.body}>
    //   <Typography variant={'h3'} className={classes.title}>   
    //  Issue Tracker <br></br>
    //  <img  */}
    // {/* //                       src={process.env.PUBLIC_URL + "github.png"} 
    // //                       style={{width:'100px',height:'100px',borderRadius:'35%'}}
    // //                       alt="MercyJemosop" 
    // //                       className="Issue Tracker"
                     
    // //                       /> */}
    // {/* //                       </Typography> */}
    // {/* //   <SearchBar value={searchTerm} onChange={setSearchTerm}/>
    // //   <RepositoryList searchTerm={searchTerm}/>
//     //   </div> */}
// {/*   
//     // </ApolloProvider>  </Container> */}
//    </div>
  );
};

export default App;
