import React from 'react';
import { Switch, Route} from 'react-router-dom';
import SearchBar from './SearchBar';
import Login from './Login';

const Routes = () => {
 return (
<Switch>
    {/* portfolio */}
    <Route exact path="/" component={Login}/>
    <Route exact path="/search" component={SearchBar}/>
</Switch>
    );
 }
export default Routes; 